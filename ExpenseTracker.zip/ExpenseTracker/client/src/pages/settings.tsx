import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { ChevronRight, Save, X, Sun, Moon } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";

// Settings section type
type SettingsSection = {
  id: string;
  title: string;
  items: SettingsItem[];
};

// Settings item type
type SettingsItem = {
  id: string;
  title: string;
  description: string;
  action: "navigate" | "toggle";
  state?: boolean;
  onToggle?: () => void;
  onClick?: () => void;
};

// Profile form schema
const profileSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  displayName: z.string().min(3, "Display name must be at least 3 characters"),
});

// Change password schema
const passwordSchema = z.object({
  currentPassword: z.string().min(6, "Current password is required"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Confirm password is required"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function Settings() {
  // User data
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Theme state management
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  
  // Apply theme changes to document
  const applyTheme = (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      document.documentElement.style.colorScheme = 'dark';
    } else {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
    }
  };
  
  // Initialize theme on component mount
  useEffect(() => {
    // Apply the current theme
    applyTheme(theme);
  }, []);
  
  // Dialog states
  const [profileDialogOpen, setProfileDialogOpen] = useState(false);
  const [securityDialogOpen, setSecurityDialogOpen] = useState(false);
  const [notificationsDialogOpen, setNotificationsDialogOpen] = useState(false);
  const [currencyDialogOpen, setCurrencyDialogOpen] = useState(false);
  
  // Form hooks
  const profileForm = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      email: user?.username || '',
      displayName: '',
    }
  });

  const passwordForm = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    }
  });

  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [weeklyReport, setWeeklyReport] = useState(true);
  
  // Currency options
  const currencies = [
    { code: "USD", name: "US Dollar" },
    { code: "EUR", name: "Euro" },
    { code: "GBP", name: "British Pound" },
    { code: "JPY", name: "Japanese Yen" },
    { code: "CAD", name: "Canadian Dollar" },
    { code: "AUD", name: "Australian Dollar" },
  ];
  const [selectedCurrency, setSelectedCurrency] = useState("USD");
  
  // Submit handlers
  const onProfileSubmit = (data: z.infer<typeof profileSchema>) => {
    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully.",
    });
    setProfileDialogOpen(false);
  };
  
  const onPasswordSubmit = (data: z.infer<typeof passwordSchema>) => {
    toast({
      title: "Password updated",
      description: "Your password has been changed successfully.",
    });
    setSecurityDialogOpen(false);
    passwordForm.reset();
  };
  
  // Settings data
  const settingsSections: SettingsSection[] = [
    {
      id: "account",
      title: "Account",
      items: [
        {
          id: "profile",
          title: "Profile Information",
          description: "Update your personal details",
          action: "navigate",
          onClick: () => setProfileDialogOpen(true)
        },
        {
          id: "security",
          title: "Security",
          description: "Change password and security settings",
          action: "navigate",
          onClick: () => setSecurityDialogOpen(true)
        },
        {
          id: "notifications",
          title: "Notifications",
          description: "Configure your notification preferences",
          action: "navigate",
          onClick: () => setNotificationsDialogOpen(true)
        }
      ]
    },
    {
      id: "expenses",
      title: "Expenses",
      items: [
        {
          id: "budget",
          title: "Budget Settings",
          description: "Set monthly and category budgets",
          action: "navigate"
        },
        {
          id: "categories",
          title: "Categories",
          description: "Customize expense categories",
          action: "navigate"
        },
        {
          id: "currency",
          title: "Currency",
          description: `${selectedCurrency} - ${currencies.find(c => c.code === selectedCurrency)?.name}`,
          action: "navigate",
          onClick: () => setCurrencyDialogOpen(true)
        }
      ]
    },
    {
      id: "app",
      title: "App",
      items: [
        {
          id: "theme",
          title: "Theme",
          description: theme === 'dark' ? "Dark Mode" : "Light Mode",
          action: "toggle",
          state: theme === 'dark',
          onToggle: () => applyTheme(theme === 'dark' ? 'light' : 'dark')
        },
        {
          id: "backup",
          title: "Data Backup",
          description: "Export and import your data",
          action: "navigate",
          onClick: () => navigate("/export")
        },
        {
          id: "about",
          title: "About",
          description: "Version 1.0.0",
          action: "navigate"
        }
      ]
    }
  ];
  
  return (
    <div className="p-4 space-y-6 pb-24 md:pb-6">
      <h2 className="text-xl font-semibold text-white mb-4">Settings</h2>
      
      {settingsSections.map((section) => (
        <Card key={section.id} className="bg-background-card border-gray-800 overflow-hidden">
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-lg font-medium text-gray-400">{section.title}</h3>
          </div>
          
          <div className="divide-y divide-gray-700">
            {section.items.map((item) => (
              <div 
                key={item.id} 
                className={`p-4 flex justify-between items-center ${item.onClick ? 'cursor-pointer' : ''}`}
                onClick={item.onClick}
              >
                <div>
                  <p className="text-white">{item.title}</p>
                  <p className="text-sm text-gray-400">{item.description}</p>
                </div>
                
                {item.action === "navigate" ? (
                  <ChevronRight className="text-gray-400 h-5 w-5" />
                ) : (
                  <Switch
                    checked={item.state}
                    onCheckedChange={item.onToggle}
                    className="data-[state=checked]:bg-neon-blue"
                  />
                )}
              </div>
            ))}
          </div>
        </Card>
      ))}

      {/* Profile Dialog */}
      <Dialog open={profileDialogOpen} onOpenChange={setProfileDialogOpen}>
        <DialogContent className="bg-background-card border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Profile Information</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update your profile details here
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                className="bg-background border-gray-700 text-white"
                {...profileForm.register("email")}
              />
              {profileForm.formState.errors.email && (
                <p className="text-red-500 text-sm">{profileForm.formState.errors.email.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="displayName">Display Name</Label>
              <Input
                id="displayName"
                className="bg-background border-gray-700 text-white"
                {...profileForm.register("displayName")}
              />
              {profileForm.formState.errors.displayName && (
                <p className="text-red-500 text-sm">{profileForm.formState.errors.displayName.message}</p>
              )}
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setProfileDialogOpen(false)}
                className="border-gray-700 text-white"
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                className="bg-neon-blue hover:bg-blue-600"
              >
                Save Changes
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Security Dialog */}
      <Dialog open={securityDialogOpen} onOpenChange={setSecurityDialogOpen}>
        <DialogContent className="bg-background-card border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update your password for better security
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="currentPassword">Current Password</Label>
              <Input
                id="currentPassword"
                type="password"
                className="bg-background border-gray-700 text-white"
                {...passwordForm.register("currentPassword")}
              />
              {passwordForm.formState.errors.currentPassword && (
                <p className="text-red-500 text-sm">{passwordForm.formState.errors.currentPassword.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="newPassword">New Password</Label>
              <Input
                id="newPassword"
                type="password"
                className="bg-background border-gray-700 text-white"
                {...passwordForm.register("newPassword")}
              />
              {passwordForm.formState.errors.newPassword && (
                <p className="text-red-500 text-sm">{passwordForm.formState.errors.newPassword.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm New Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                className="bg-background border-gray-700 text-white"
                {...passwordForm.register("confirmPassword")}
              />
              {passwordForm.formState.errors.confirmPassword && (
                <p className="text-red-500 text-sm">{passwordForm.formState.errors.confirmPassword.message}</p>
              )}
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setSecurityDialogOpen(false)}
                className="border-gray-700 text-white"
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                className="bg-neon-blue hover:bg-blue-600"
              >
                Change Password
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Notifications Dialog */}
      <Dialog open={notificationsDialogOpen} onOpenChange={setNotificationsDialogOpen}>
        <DialogContent className="bg-background-card border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Notification Settings</DialogTitle>
            <DialogDescription className="text-gray-400">
              Configure your notification preferences
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white">Email Notifications</p>
                <p className="text-sm text-gray-400">Receive important updates via email</p>
              </div>
              <Switch
                checked={emailNotifications}
                onCheckedChange={setEmailNotifications}
                className="data-[state=checked]:bg-neon-blue"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white">Push Notifications</p>
                <p className="text-sm text-gray-400">Receive mobile push notifications</p>
              </div>
              <Switch
                checked={pushNotifications}
                onCheckedChange={setPushNotifications}
                className="data-[state=checked]:bg-neon-blue"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white">Weekly Report</p>
                <p className="text-sm text-gray-400">Get a summary of your expenses weekly</p>
              </div>
              <Switch
                checked={weeklyReport}
                onCheckedChange={setWeeklyReport}
                className="data-[state=checked]:bg-neon-blue"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => setNotificationsDialogOpen(false)}
              className="bg-neon-blue hover:bg-blue-600"
            >
              Save Settings
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Currency Dialog */}
      <Dialog open={currencyDialogOpen} onOpenChange={setCurrencyDialogOpen}>
        <DialogContent className="bg-background-card border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Currency Settings</DialogTitle>
            <DialogDescription className="text-gray-400">
              Choose your preferred currency
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 max-h-[60vh] overflow-auto">
            {currencies.map((currency) => (
              <div 
                key={currency.code} 
                className={`p-3 flex items-center justify-between cursor-pointer rounded-lg ${selectedCurrency === currency.code ? 'bg-blue-900/30 border border-neon-blue' : 'hover:bg-gray-800'}`}
                onClick={() => setSelectedCurrency(currency.code)}
              >
                <div>
                  <p className="text-white">{currency.code}</p>
                  <p className="text-sm text-gray-400">{currency.name}</p>
                </div>
                {selectedCurrency === currency.code && (
                  <div className="h-3 w-3 rounded-full bg-neon-blue"></div>
                )}
              </div>
            ))}
          </div>
          
          <DialogFooter>
            <Button
              onClick={() => setCurrencyDialogOpen(false)}
              className="bg-neon-blue hover:bg-blue-600"
            >
              Save Currency
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
