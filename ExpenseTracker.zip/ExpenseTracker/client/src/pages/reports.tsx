import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Download, Share2 } from "lucide-react";
import TrendsChart from "@/components/trends-chart";
import { MonthlyExpenseSummary, ExpenseSummary } from "@shared/schema";

type TimePeriod = "this-month" | "last-month" | "last-3-months" | "this-year" | "custom";

export default function Reports() {
  const [period, setPeriod] = useState<TimePeriod>("this-month");
  
  // Get current month and year
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();
  
  // Fetch summary for the selected period
  const { data: summary, isLoading } = useQuery<MonthlyExpenseSummary>({
    queryKey: ['/api/summary', { month: currentMonth, year: currentYear }],
  });
  
  // Fetch category data
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<ExpenseSummary[]>({
    queryKey: ['/api/categories', { month: currentMonth, year: currentYear }],
  });
  
  return (
    <div className="p-4 space-y-6">
      <h2 className="text-xl font-semibold text-white mb-4">Expense Reports</h2>
      
      {/* Time Period Selector */}
      <div className="flex overflow-x-auto space-x-3 py-2 mb-4">
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full whitespace-nowrap ${period === "this-month" ? "text-neon-blue border-neon-blue shadow-neon-blue" : "text-gray-300 border-gray-700 bg-background-card"}`}
          onClick={() => setPeriod("this-month")}
        >
          This Month
        </Button>
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full whitespace-nowrap ${period === "last-month" ? "text-neon-blue border-neon-blue shadow-neon-blue" : "text-gray-300 border-gray-700 bg-background-card"}`}
          onClick={() => setPeriod("last-month")}
        >
          Last Month
        </Button>
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full whitespace-nowrap ${period === "last-3-months" ? "text-neon-blue border-neon-blue shadow-neon-blue" : "text-gray-300 border-gray-700 bg-background-card"}`}
          onClick={() => setPeriod("last-3-months")}
        >
          Last 3 Months
        </Button>
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full whitespace-nowrap ${period === "this-year" ? "text-neon-blue border-neon-blue shadow-neon-blue" : "text-gray-300 border-gray-700 bg-background-card"}`}
          onClick={() => setPeriod("this-year")}
        >
          This Year
        </Button>
        <Button
          variant="outline"
          size="sm"
          className={`rounded-full whitespace-nowrap ${period === "custom" ? "text-neon-blue border-neon-blue shadow-neon-blue" : "text-gray-300 border-gray-700 bg-background-card"}`}
          onClick={() => setPeriod("custom")}
        >
          Custom Range
        </Button>
      </div>
      
      {/* Spending Trends Chart */}
      <Card className="bg-background-card border-gray-800 shadow-lg">
        <CardContent className="pt-4">
          <h3 className="text-lg font-medium text-gray-400 mb-4">Spending Trends</h3>
          
          {isLoading ? (
            <div className="h-64 w-full flex items-center justify-center">
              <Skeleton className="h-48 w-full bg-gray-800" />
            </div>
          ) : (
            <TrendsChart data={summary} period={period} />
          )}
        </CardContent>
      </Card>
      
      {/* Top Spending Categories */}
      <Card className="bg-background-card border-gray-800 shadow-lg">
        <CardContent className="pt-4">
          <h3 className="text-lg font-medium text-gray-400 mb-4">Top Categories</h3>
          
          {isCategoriesLoading ? (
            <>
              {[1, 2, 3].map((i) => (
                <div key={i} className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <Skeleton className="h-5 w-32 bg-gray-800" />
                    <Skeleton className="h-5 w-24 bg-gray-800" />
                  </div>
                  <Skeleton className="h-2 w-full bg-gray-800" />
                </div>
              ))}
            </>
          ) : (
            <>
              {categories?.slice(0, 5).map((category, index) => (
                <div key={index} className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-white">
                      {EXPENSE_CATEGORIES.find(c => c.id === category.category)?.name || category.category}
                    </span>
                    <span className="text-gray-300 font-mono">
                      ${category.total.toFixed(2)} ({category.percentage}%)
                    </span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full bg-${getCategoryColor(category.category)}`}
                      style={{ width: `${category.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
              
              {(!categories || categories.length === 0) && (
                <div className="py-8 text-center text-gray-400">
                  <p>No data available for the selected period.</p>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
      
      {/* Export Options */}
      <div className="flex space-x-3">
        <Button variant="outline" className="flex-1 bg-gray-800 text-white">
          <Download className="w-4 h-4 mr-2" /> Export PDF
        </Button>
        <Button variant="outline" className="flex-1 bg-gray-800 text-white">
          <Share2 className="w-4 h-4 mr-2" /> Share Report
        </Button>
      </div>
    </div>
  );
}

// Helper function to get the category color class
function getCategoryColor(categoryId: string): string {
  const category = EXPENSE_CATEGORIES.find(c => c.id === categoryId);
  return category ? category.color : "gray-400";
}

// Import category data
import { EXPENSE_CATEGORIES } from "@shared/schema";
