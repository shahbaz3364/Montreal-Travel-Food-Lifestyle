import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import BudgetProgress from "@/components/budget-progress";
import CategoryChart from "@/components/category-chart";
import ExpenseListItem from "@/components/expense-list-item";
import { Button } from "@/components/ui/button";
import { type Expense, type MonthlyExpenseSummary } from "@shared/schema";
import { useLocation } from 'wouter';
import { ChevronRight, PlusCircle } from 'lucide-react';
import { AnimatedContainer, AnimatedItem } from "@/components/ui/animated-container";
import { AnimatedButton } from "@/components/ui/animated-button";
import { AnimatedIcon } from "@/components/ui/animated-icon";

export default function Dashboard() {
  const [, navigate] = useLocation();
  
  // Fetch monthly summary
  const { data: summary, isLoading: isSummaryLoading } = useQuery<MonthlyExpenseSummary>({
    queryKey: ['/api/summary'],
  });
  
  // Fetch recent transactions
  const { data: recentExpenses, isLoading: isExpensesLoading } = useQuery<Expense[]>({
    queryKey: ['/api/expenses/recent'],
  });

  return (
    <AnimatedContainer className="p-4 space-y-6" animation="fadeIn">
      {/* Monthly Summary Card */}
      <AnimatedItem animation="slideInUp" delay={0.1}>
        <Card className="bg-background-card border-gray-800 shadow-lg">
          <CardContent className="pt-4">
            <h2 className="text-lg font-medium text-gray-400 mb-2">This Month</h2>
            
            {isSummaryLoading ? (
              <>
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <p className="text-sm text-gray-400">Total Spent</p>
                    <Skeleton className="h-8 w-32 bg-gray-800 mt-1" />
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-400">Budget</p>
                    <Skeleton className="h-6 w-24 bg-gray-800 mt-1 ml-auto" />
                  </div>
                </div>
                <Skeleton className="h-2 w-full bg-gray-800 mt-4" />
              </>
            ) : (
              <>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-sm text-gray-400">Total Spent</p>
                    <p className="text-3xl font-mono font-medium text-white">
                      ${summary?.totalSpent.toFixed(2)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-400">Budget</p>
                    <div className="flex items-center">
                      <p className="text-lg font-mono font-medium text-white mr-2">
                        ${summary?.budgetRemaining.toFixed(2)}
                      </p>
                      <span className="text-sm text-status-warning">left</span>
                    </div>
                  </div>
                </div>
                
                <BudgetProgress 
                  percentage={summary?.budgetPercentage || 0} 
                  className="mt-4" 
                />
              </>
            )}
          </CardContent>
        </Card>
      </AnimatedItem>
      
      {/* Categories Chart */}
      <AnimatedItem animation="slideInUp" delay={0.2}>
        <Card className="bg-background-card border-gray-800 shadow-lg">
          <CardContent className="pt-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-400">Spending by Category</h2>
              <Button variant="link" className="text-neon-blue p-0 group">
                See All
                <AnimatedIcon 
                  icon={ChevronRight} 
                  size={16} 
                  className="ml-1 transition-transform group-hover:translate-x-1" 
                  animationType="none"
                />
              </Button>
            </div>
            
            {isSummaryLoading ? (
              <div className="h-[240px] flex items-center justify-center">
                <Skeleton className="h-40 w-40 rounded-full bg-gray-800" />
              </div>
            ) : (
              <CategoryChart categories={summary?.categories || []} />
            )}
          </CardContent>
        </Card>
      </AnimatedItem>
      
      {/* Recent Transactions */}
      <AnimatedItem animation="slideInUp" delay={0.3}>
        <Card className="bg-background-card border-gray-800 shadow-lg">
          <CardContent className="pt-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-400">Recent Transactions</h2>
              <Button variant="link" className="text-neon-blue p-0 group">
                View All
                <AnimatedIcon 
                  icon={ChevronRight} 
                  size={16} 
                  className="ml-1 transition-transform group-hover:translate-x-1" 
                  animationType="none"
                />
              </Button>
            </div>
            
            {isExpensesLoading ? (
              <>
                {[1, 2, 3].map((i) => (
                  <div key={i} className="border-b border-gray-700 py-3 flex items-center">
                    <Skeleton className="h-10 w-10 rounded-full bg-gray-800 mr-3" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-32 bg-gray-800 mb-1" />
                      <Skeleton className="h-4 w-24 bg-gray-800" />
                    </div>
                    <Skeleton className="h-5 w-16 bg-gray-800" />
                  </div>
                ))}
              </>
            ) : (
              <>
                <AnimatedContainer animation="staggered">
                  {recentExpenses?.map((expense) => (
                    <AnimatedItem key={expense.id} animation="staggered">
                      <ExpenseListItem expense={expense} />
                    </AnimatedItem>
                  ))}
                </AnimatedContainer>
                
                {recentExpenses?.length === 0 && (
                  <div className="py-8 text-center text-gray-400">
                    <p>No recent transactions</p>
                    <AnimatedButton 
                      variant="link" 
                      className="text-neon-blue mt-2 flex items-center mx-auto"
                      animationType="bounce"
                      onClick={() => navigate('/add-expense')}
                    >
                      <AnimatedIcon 
                        icon={PlusCircle} 
                        className="mr-1" 
                        size={16} 
                        animationType="pulse"
                      />
                      Add your first expense
                    </AnimatedButton>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </AnimatedItem>
    </AnimatedContainer>
  );
}
