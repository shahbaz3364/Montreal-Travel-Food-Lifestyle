import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { insertExpenseSchema, EXPENSE_CATEGORIES, type ExpenseCategory } from "@shared/schema";
import CategoryButton from "@/components/category-button";

export default function AddExpense() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<ExpenseCategory | null>(null);
  
  // Parse URL parameters to get the date if provided
  const params = new URLSearchParams(window.location.search);
  const dateParam = params.get('date');
  
  // Get default date (today or from URL parameter)
  const defaultDate = dateParam ? new Date(dateParam) : new Date();
  const today = defaultDate.toISOString().split('T')[0];
  
  const form = useForm({
    resolver: zodResolver(insertExpenseSchema),
    defaultValues: {
      amount: undefined,
      category: undefined,
      description: "",
      date: defaultDate,
    }
  });
  
  const mutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/expenses", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/summary'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/monthly'] });
      toast({
        title: "Expense Added",
        description: "Your expense has been successfully recorded.",
      });
      // Navigate back to calendar if we came from there
      if (dateParam) {
        navigate("/calendar");
      } else {
        navigate("/");
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add expense. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  const onSubmit = (data: any) => {
    mutation.mutate(data);
  };
  
  const handleCategorySelect = (category: ExpenseCategory) => {
    setSelectedCategory(category);
    form.setValue('category', category as any);
  };
  
  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center mb-4">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => {
            // If we came from calendar, go back there, otherwise go to home
            if (dateParam) {
              navigate("/calendar");
            } else {
              navigate("/");
            }
          }}
          className="mr-3"
        >
          <ArrowLeft className="text-gray-300" />
        </Button>
        <h2 className="text-xl font-semibold text-white">Add Expense</h2>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Amount Input */}
          <Card className="bg-background-card border-gray-800">
            <CardContent className="pt-4">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm text-gray-400">Amount</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute top-3 left-4 text-xl text-gray-400">$</span>
                        <Input
                          {...field}
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          className="bg-gray-800 border-gray-700 text-white text-2xl font-mono p-2 pl-10 h-auto"
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          {/* Category Selection */}
          <Card className="bg-background-card border-gray-800">
            <CardContent className="pt-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm text-gray-400 block mb-3">Category</FormLabel>
                    <div className="grid grid-cols-4 gap-3">
                      {EXPENSE_CATEGORIES.map((category) => (
                        <CategoryButton
                          key={category.id}
                          category={category}
                          isSelected={selectedCategory === category.id}
                          onClick={() => handleCategorySelect(category.id)}
                        />
                      ))}
                    </div>
                    <input type="hidden" {...field} />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          {/* Description (Optional) */}
          <Card className="bg-background-card border-gray-800">
            <CardContent className="pt-4">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm text-gray-400">Description (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="What was this expense for?"
                        className="bg-gray-800 border-gray-700 text-white"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          {/* Date Selection */}
          <Card className="bg-background-card border-gray-800">
            <CardContent className="pt-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm text-gray-400">Date</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute top-3 left-4 text-gray-400 material-icons">calendar_today</span>
                        <Input
                          type="date"
                          defaultValue={today}
                          className="bg-gray-800 border-gray-700 text-white pl-12"
                          onChange={(e) => field.onChange(new Date(e.target.value))}
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          {/* Save Button */}
          <Button 
            type="submit" 
            className="w-full bg-neon-blue text-black font-medium py-7 h-auto rounded-xl hover:bg-opacity-90 transition-colors shadow-neon-blue"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? "Saving..." : "Save Expense"}
          </Button>
        </form>
      </Form>
    </div>
  );
}
