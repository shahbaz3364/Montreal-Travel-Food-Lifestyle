import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DatePicker } from "@/components/ui/date-picker";
import { Separator } from "@/components/ui/separator";
import { Calendar, FileText, FileSpreadsheet, Download, FileDown, ArrowLeft } from "lucide-react";
import { format, subMonths, isAfter } from "date-fns";
import { AnimatedContainer, AnimatedItem } from "@/components/ui/animated-container";
import { AnimatedIcon } from "@/components/ui/animated-icon";
import { AnimatedButton } from "@/components/ui/animated-button";
import { useLocation } from "wouter";

// Date range presets
const DATE_RANGES = [
  { id: "current_month", label: "Current Month" },
  { id: "last_month", label: "Last Month" },
  { id: "last_3_months", label: "Last 3 Months" },
  { id: "last_6_months", label: "Last 6 Months" },
  { id: "year_to_date", label: "Year to Date" },
  { id: "last_year", label: "Last Year" },
  { id: "custom", label: "Custom Range" },
];

export default function ExportPage() {
  const [, navigate] = useLocation();
  const [selectedTab, setSelectedTab] = useState("pdf");
  const [selectedRange, setSelectedRange] = useState("current_month");
  const [startDate, setStartDate] = useState<Date>(
    new Date(new Date().getFullYear(), new Date().getMonth(), 1)
  );
  const [endDate, setEndDate] = useState<Date>(new Date());
  const [isExporting, setIsExporting] = useState(false);

  // Update date range based on preset selection
  const handleRangeChange = (value: string) => {
    setSelectedRange(value);
    
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth();
    
    switch (value) {
      case "current_month":
        setStartDate(new Date(currentYear, currentMonth, 1));
        setEndDate(today);
        break;
      case "last_month":
        setStartDate(new Date(currentYear, currentMonth - 1, 1));
        setEndDate(new Date(currentYear, currentMonth, 0));
        break;
      case "last_3_months":
        setStartDate(new Date(currentYear, currentMonth - 3, 1));
        setEndDate(today);
        break;
      case "last_6_months":
        setStartDate(new Date(currentYear, currentMonth - 6, 1));
        setEndDate(today);
        break;
      case "year_to_date":
        setStartDate(new Date(currentYear, 0, 1));
        setEndDate(today);
        break;
      case "last_year":
        setStartDate(new Date(currentYear - 1, 0, 1));
        setEndDate(new Date(currentYear - 1, 11, 31));
        break;
      case "custom":
        // Keep existing dates for custom range
        break;
    }
  };

  // Ensure end date is not before start date
  const handleStartDateChange = (date: Date | undefined) => {
    if (date) {
      setStartDate(date);
      if (isAfter(date, endDate)) {
        setEndDate(date);
      }
    }
  };

  // Create URL with query parameters
  const createExportUrl = (fileType: "pdf" | "csv") => {
    const endpoint = fileType === "pdf" ? "/api/export/pdf" : "/api/export/csv";
    const params = new URLSearchParams({
      startDate: format(startDate, "yyyy-MM-dd"),
      endDate: format(endDate, "yyyy-MM-dd"),
    });
    
    return `${endpoint}?${params.toString()}`;
  };

  // Handle export button click
  const handleExport = () => {
    setIsExporting(true);
    
    try {
      // Create download link
      const exportUrl = createExportUrl(selectedTab as "pdf" | "csv");
      const link = document.createElement("a");
      link.href = exportUrl;
      link.target = "_blank";
      
      // Simulate file name that would come from server
      const extension = selectedTab === "pdf" ? "pdf" : "xlsx";
      const fileName = `expenses-${format(startDate, "yyyy-MM-dd")}-to-${format(endDate, "yyyy-MM-dd")}.${extension}`;
      
      // Open in new tab (since download attribute may not work for direct server responses)
      link.click();
    } catch (error) {
      console.error("Export error:", error);
    } finally {
      setTimeout(() => setIsExporting(false), 1000);
    }
  };

  return (
    <AnimatedContainer animation="fadeIn" className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center">
        <Button 
          variant="outline" 
          size="icon" 
          className="mr-4" 
          onClick={() => navigate("/settings")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-semibold">Export Data</h1>
      </div>
      
      <AnimatedItem delay={0.1} animation="slideInUp">
        <Card className="bg-background-card border-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileDown className="mr-2 h-5 w-5 text-neon-blue" />
              Export Your Expenses
            </CardTitle>
            <CardDescription>
              Download your expense data in different formats for backup or analysis
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {/* File Type Tabs */}
            <div className="mb-6">
              <Label className="mb-2 block">Export Format</Label>
              <Tabs defaultValue="pdf" value={selectedTab} onValueChange={setSelectedTab}>
                <TabsList className="grid grid-cols-2 w-full max-w-md">
                  <TabsTrigger value="pdf" className="flex items-center justify-center">
                    <FileText className="mr-2 h-4 w-4" />
                    PDF Report
                  </TabsTrigger>
                  <TabsTrigger value="csv" className="flex items-center justify-center">
                    <FileSpreadsheet className="mr-2 h-4 w-4" />
                    Excel/CSV
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="pdf" className="mt-4">
                  <div className="rounded-md bg-gray-800/30 p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-neon-blue/10 rounded-lg p-2">
                        <FileText className="h-6 w-6 text-neon-blue" />
                      </div>
                      <div>
                        <h3 className="font-medium">PDF Export</h3>
                        <p className="text-sm text-gray-400">
                          Perfect for printing or sharing a formatted report of your expenses.
                          Includes summary information and transaction details.
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="csv" className="mt-4">
                  <div className="rounded-md bg-gray-800/30 p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-neon-blue/10 rounded-lg p-2">
                        <FileSpreadsheet className="h-6 w-6 text-neon-blue" />
                      </div>
                      <div>
                        <h3 className="font-medium">Excel Export</h3>
                        <p className="text-sm text-gray-400">
                          Download your expense data in Excel format for further analysis, 
                          budgeting, or import into other financial tools.
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            
            <Separator className="my-6 bg-gray-700" />
            
            {/* Date Range Selection */}
            <div className="space-y-4">
              <Label className="mb-2 block">Date Range</Label>
              <RadioGroup 
                defaultValue="current_month" 
                value={selectedRange}
                onValueChange={handleRangeChange}
                className="grid grid-cols-1 md:grid-cols-2 gap-2"
              >
                {DATE_RANGES.map((range) => (
                  <div key={range.id} className="flex items-center space-x-2">
                    <RadioGroupItem value={range.id} id={range.id} />
                    <Label htmlFor={range.id} className="cursor-pointer">{range.label}</Label>
                  </div>
                ))}
              </RadioGroup>
              
              {/* Custom Date Range */}
              {selectedRange === "custom" && (
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-4 bg-gray-800/30 p-4 rounded-lg">
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="start-date">Start Date</Label>
                    <DatePicker
                      id="start-date"
                      date={startDate}
                      onSelect={handleStartDateChange}
                      className="w-full"
                    />
                  </div>
                  
                  <div className="text-center self-center hidden sm:block">
                    <span className="text-gray-400">to</span>
                  </div>
                  
                  <div className="space-y-2 flex-1">
                    <Label htmlFor="end-date">End Date</Label>
                    <DatePicker 
                      id="end-date"
                      date={endDate}
                      onSelect={(date: Date | undefined) => date && setEndDate(date)}
                      fromDate={startDate}
                      className="w-full"
                    />
                  </div>
                </div>
              )}
            </div>
            
            {/* Summary */}
            <div className="mt-6 border border-gray-700 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-sm text-gray-400 mb-2">Export Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 text-neon-blue mr-2" />
                  <span className="text-sm">
                    From: <span className="font-medium">{format(startDate, "MMMM d, yyyy")}</span>
                  </span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 text-neon-blue mr-2" />
                  <span className="text-sm">
                    To: <span className="font-medium">{format(endDate, "MMMM d, yyyy")}</span>
                  </span>
                </div>
                <div className="flex items-center">
                  <FileText className="h-4 w-4 text-neon-blue mr-2" />
                  <span className="text-sm">
                    Format: <span className="font-medium">{selectedTab === "pdf" ? "PDF Report" : "Excel Spreadsheet"}</span>
                  </span>
                </div>
              </div>
            </div>
            
            {/* Export Button */}
            <AnimatedButton
              onClick={handleExport}
              animationType="bounce"
              className="bg-neon-blue hover:bg-blue-500 text-black w-full flex items-center justify-center"
              disabled={isExporting}
            >
              {isExporting ? (
                <>
                  <AnimatedIcon 
                    icon={Download} 
                    className="mr-2" 
                    animationType="pulse" 
                    autoAnimate={true}
                  />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-5 w-5" />
                  Download {selectedTab.toUpperCase()} Export
                </>
              )}
            </AnimatedButton>
          </CardContent>
        </Card>
      </AnimatedItem>
    </AnimatedContainer>
  );
}