import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format, addMonths, subMonths, isToday, isSameMonth, isSameDay } from "date-fns";
import { type Expense, EXPENSE_CATEGORIES } from "@shared/schema";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, PiggyBank, Clock, ArrowUpRight } from "lucide-react";

export default function Calendar() {
  const [, navigate] = useLocation();
  const [date, setDate] = useState<Date>(new Date());
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [activeTab, setActiveTab] = useState<string>("expenses");
  
  // Get current month and year for API call
  const month = currentMonth.getMonth() + 1;
  const year = currentMonth.getFullYear();
  
  // Fetch monthly expenses
  const { data: expenses, isLoading } = useQuery<Expense[]>({
    queryKey: ['/api/expenses/monthly', { month, year }],
  });
  
  // Navigate through months
  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const goToToday = () => {
    const today = new Date();
    setCurrentMonth(today);
    setDate(today);
  };
  
  // Group expenses by date
  const expensesByDate = expenses?.reduce((acc, expense) => {
    const expenseDate = new Date(expense.date);
    const dateStr = format(expenseDate, 'yyyy-MM-dd');
    
    if (!acc[dateStr]) {
      acc[dateStr] = [];
    }
    
    acc[dateStr].push(expense);
    return acc;
  }, {} as Record<string, Expense[]>) || {};
  
  // Calculate totals
  const selectedDateStr = format(date, 'yyyy-MM-dd');
  const selectedDayExpenses = expensesByDate[selectedDateStr] || [];
  const totalForSelectedDay = selectedDayExpenses.reduce(
    (sum, expense) => sum + Number(expense.amount), 0
  );
  
  const totalForCurrentMonth = expenses?.reduce(
    (sum, expense) => sum + Number(expense.amount), 0
  ) || 0;
  
  // Custom day rendering with expense indicators
  const getDayContent = (day: Date) => {
    if (!day) return null;
    
    try {
      const dateStr = format(day, 'yyyy-MM-dd');
      const dayExpenses = expensesByDate[dateStr];
      
      if (!dayExpenses || dayExpenses.length === 0) return null;
      
      const total = dayExpenses.reduce((sum, expense) => sum + Number(expense.amount), 0);
      const hasManyExpenses = dayExpenses.length > 2;
      
      return (
        <div className="w-full h-full flex justify-center items-end pb-1">
          <div className={`text-[10px] font-medium rounded-full px-1 ${
            hasManyExpenses 
              ? 'bg-red-500/20 text-red-300 dark:text-red-300' 
              : 'bg-blue-500/20 text-neon-blue dark:text-neon-blue'
          }`}>
            ${total.toFixed(0)}
          </div>
        </div>
      );
    } catch (error) {
      console.error("Error rendering day content:", error);
      return null;
    }
  };
  
  // Make sure we stay in sync with the current month view
  useEffect(() => {
    if (!isSameMonth(date, currentMonth)) {
      setCurrentMonth(date);
    }
  }, [date]);
  
  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-8rem)] overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
        {/* Left side: Calendar */}
        <div className="md:col-span-2 flex flex-col">
          <Card className="bg-background-card border-gray-800 shadow-lg flex-grow overflow-hidden">
            <CardHeader className="border-b border-gray-700 pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CalendarIcon className="h-5 w-5 text-neon-blue" />
                  <CardTitle className="text-lg font-medium">
                    {format(currentMonth, 'MMMM yyyy')}
                  </CardTitle>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-8 w-8 border-gray-700 dark:hover:bg-gray-800 dark:hover:text-white"
                    onClick={prevMonth}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    className="h-8 px-3 border-gray-700 dark:hover:bg-gray-800 dark:hover:text-white"
                    onClick={goToToday}
                  >
                    Today
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-8 w-8 border-gray-700 dark:hover:bg-gray-800 dark:hover:text-white"
                    onClick={nextMonth}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <div className="p-4 flex-grow overflow-auto">
              <CalendarComponent
                mode="single"
                selected={date}
                onSelect={(newDate) => newDate && setDate(newDate)}
                month={currentMonth}
                onMonthChange={setCurrentMonth}
                className="rounded-md w-full"
                components={{
                  DayContent: (props: any) => {
                    const day = props.date;
                    return (
                      <div className="relative h-full flex flex-col items-center justify-start">
                        <div
                          className={`flex items-center justify-center h-8 w-8 rounded-full ${
                            isToday(day) ? 'border border-neon-blue' : ''
                          } ${
                            isSameDay(day, date) ? 'bg-neon-blue dark:bg-neon-blue text-black dark:text-black' : ''
                          }`}
                        >
                          {format(day, 'd')}
                        </div>
                        {getDayContent(day)}
                      </div>
                    );
                  }
                }}
                showOutsideDays={true}
                styles={{
                  head_cell: {
                    width: 'calc(100% / 7)',
                    textAlign: 'center',
                    padding: '0.75rem 0',
                    fontWeight: 'medium',
                    color: 'var(--gray-400)',
                  },
                  day: {
                    width: 'calc(100% / 7)',
                    height: '5rem',
                    margin: '0',
                    padding: '0.25rem',
                    position: 'relative',
                    textAlign: 'center',
                    display: 'flex',
                    alignItems: 'start',
                    justifyContent: 'center',
                    borderRight: '1px solid rgba(75, 85, 99, 0.3)',
                    borderBottom: '1px solid rgba(75, 85, 99, 0.3)',
                  },
                  caption: {
                    display: 'none',
                  },
                  table: {
                    width: '100%',
                    borderCollapse: 'collapse',
                    captionSide: 'bottom',
                    backgroundColor: 'transparent',
                    border: 'none'
                  },
                  head_row: {
                    borderBottom: '1px solid rgba(75, 85, 99, 0.3)',
                  },
                  row: {
                    width: '100%',
                    backgroundColor: 'transparent',
                    border: 'none'
                  },
                }}
              />
            </div>
          </Card>
        </div>
        
        {/* Right side: Details */}
        <div className="md:col-span-1 flex flex-col overflow-hidden">
          <Card className="bg-background-card border-gray-800 shadow-lg flex-grow">
            <CardHeader className="border-b border-gray-700 pb-3">
              <div className="flex flex-col space-y-1">
                <CardTitle className="text-lg font-medium flex items-center">
                  {format(date, 'MMMM d, yyyy')}
                  {isToday(date) && (
                    <Badge className="ml-2 bg-neon-blue text-black">Today</Badge>
                  )}
                </CardTitle>
                <p className="text-sm text-gray-400">
                  {selectedDayExpenses.length} expense{selectedDayExpenses.length !== 1 ? 's' : ''}
                </p>
              </div>
            </CardHeader>
            
            <div className="p-4 grid grid-cols-2 gap-4">
              <Card className="bg-gray-800/50 border-gray-700">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <PiggyBank className="h-5 w-5 text-neon-blue mb-1" />
                  <p className="text-sm text-gray-300">Daily Total</p>
                  <p className="text-xl font-semibold text-white">${totalForSelectedDay.toFixed(2)}</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800/50 border-gray-700">
                <CardContent className="p-4 flex flex-col items-center justify-center">
                  <ArrowUpRight className="h-5 w-5 text-neon-blue mb-1" />
                  <p className="text-sm text-gray-300">Monthly</p>
                  <p className="text-xl font-semibold text-white">${totalForCurrentMonth.toFixed(2)}</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="px-4 pb-2">
              <Tabs defaultValue="expenses" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-2 mb-4 bg-gray-800/50">
                  <TabsTrigger value="expenses" className="data-[state=active]:bg-neon-blue data-[state=active]:text-black">
                    Expenses
                  </TabsTrigger>
                  <TabsTrigger value="stats" className="data-[state=active]:bg-neon-blue data-[state=active]:text-black">
                    Stats
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="expenses" className="m-0 overflow-auto max-h-[calc(100vh-24rem)]">
                  {isLoading ? (
                    <>
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="mb-4 flex justify-between items-center">
                          <div className="flex items-center">
                            <Skeleton className="h-10 w-10 rounded-full bg-gray-800 mr-3" />
                            <div>
                              <Skeleton className="h-5 w-32 bg-gray-800 mb-1" />
                              <Skeleton className="h-4 w-24 bg-gray-800" />
                            </div>
                          </div>
                          <Skeleton className="h-5 w-16 bg-gray-800" />
                        </div>
                      ))}
                    </>
                  ) : (
                    <>
                      {selectedDayExpenses.length > 0 ? (
                        selectedDayExpenses.map((expense) => {
                          const category = EXPENSE_CATEGORIES.find(c => c.id === expense.category);
                          return (
                            <div key={expense.id} className="mb-4 flex justify-between items-center border-b border-gray-700 pb-3 last:border-0">
                              <div className="flex items-center">
                                <div className={`w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center mr-3`}>
                                  <span className="text-neon-blue">
                                    {category?.icon || '💰'}
                                  </span>
                                </div>
                                <div>
                                  <p className="text-white dark:text-white">{expense.description || category?.name || 'Expense'}</p>
                                  <p className="text-xs text-gray-400 flex items-center">
                                    <Clock className="h-3 w-3 mr-1" />
                                    {format(new Date(expense.date), 'h:mm a')}
                                  </p>
                                </div>
                              </div>
                              <p className="font-mono text-white dark:text-white">-${Number(expense.amount).toFixed(2)}</p>
                            </div>
                          );
                        })
                      ) : (
                        <div className="py-8 text-center text-gray-400">
                          <p>No expenses recorded for this date</p>
                          <Button 
                            className="mt-4 bg-neon-blue hover:bg-blue-500 text-black" 
                            size="sm"
                            onClick={() => {
                              const params = new URLSearchParams({
                                date: format(date, 'yyyy-MM-dd')
                              }).toString();
                              navigate(`/add-expense?${params}`);
                            }}
                          >
                            Add Expense
                          </Button>
                        </div>
                      )}
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="stats" className="m-0">
                  <div className="py-4 flex flex-col items-center justify-center">
                    {/* This would be expanded with actual stats in a real implementation */}
                    <div className="w-full max-w-xs mb-4">
                      <p className="text-sm text-gray-400 mb-1">Expense Categories</p>
                      {selectedDayExpenses.length > 0 ? (
                        <div className="space-y-2">
                          {Object.entries(
                            selectedDayExpenses.reduce((acc, expense) => {
                              const category = expense.category;
                              if (!acc[category]) acc[category] = 0;
                              acc[category] += Number(expense.amount);
                              return acc;
                            }, {} as Record<string, number>)
                          ).map(([categoryId, amount]) => {
                            const category = EXPENSE_CATEGORIES.find(c => c.id === categoryId);
                            return (
                              <div key={categoryId} className="flex justify-between items-center">
                                <div className="flex items-center">
                                  <div className="w-2 h-2 rounded-full bg-neon-blue mr-2" />
                                  <span className="text-sm text-white dark:text-white">{category?.name || categoryId}</span>
                                </div>
                                <span className="text-sm text-white dark:text-white">${amount.toFixed(2)}</span>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <p className="text-center text-gray-400 py-4">No data to display</p>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}