import { motion, MotionProps, Variants } from "framer-motion";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

// Animation variants
export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: { 
    opacity: 1,
    transition: { duration: 0.3 }
  }
};

export const slideInUp: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      type: "spring", 
      stiffness: 300, 
      damping: 24 
    }
  }
};

export const slideInLeft: Variants = {
  hidden: { opacity: 0, x: 20 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { 
      type: "spring", 
      stiffness: 300, 
      damping: 24 
    }
  }
};

export const popIn: Variants = {
  hidden: { scale: 0.8, opacity: 0 },
  visible: { 
    scale: 1, 
    opacity: 1,
    transition: { 
      type: "spring", 
      stiffness: 400, 
      damping: 20 
    }
  }
};

export const staggeredChildren: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1
    }
  }
};

export const staggeredItem: Variants = {
  hidden: { opacity: 0, y: 10 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      type: "spring", 
      stiffness: 300, 
      damping: 20
    }
  }
};

export const buttonTap = {
  scale: 0.95
};

export const pulse = {
  scale: [1, 1.05, 1],
  transition: { duration: 0.3 }
};

interface AnimatedContainerProps extends MotionProps {
  children: ReactNode;
  className?: string;
  animation?: "fadeIn" | "slideInUp" | "slideInLeft" | "popIn" | "staggered";
  delay?: number;
  noInitialAnimation?: boolean;
}

export function AnimatedContainer({
  children,
  className,
  animation = "fadeIn",
  delay = 0,
  noInitialAnimation = false,
  ...props
}: AnimatedContainerProps) {
  // Choose the correct variant based on the animation prop
  const getVariant = (): Variants => {
    switch (animation) {
      case "slideInUp":
        return slideInUp;
      case "slideInLeft":
        return slideInLeft;  
      case "popIn":
        return popIn;
      case "staggered":
        return staggeredChildren;
      case "fadeIn":
      default:
        return fadeIn;
    }
  };

  return (
    <motion.div
      className={cn(className)}
      initial={noInitialAnimation ? "visible" : "hidden"}
      animate="visible"
      exit="hidden"
      variants={getVariant()}
      transition={{ delay }}
      {...props}
    >
      {children}
    </motion.div>
  );
}

export function AnimatedItem({
  children,
  className,
  animation = "fadeIn",
  delay = 0,
  noInitialAnimation = false,
  ...props
}: AnimatedContainerProps) {
  return (
    <motion.div
      className={cn(className)}
      variants={animation === "staggered" ? staggeredItem : undefined}
      initial={noInitialAnimation ? undefined : { opacity: 0, y: 10 }}
      animate={noInitialAnimation ? undefined : { opacity: 1, y: 0 }}
      transition={{ 
        delay, 
        type: "spring", 
        stiffness: 300, 
        damping: 20 
      }}
      {...props}
    >
      {children}
    </motion.div>
  );
}