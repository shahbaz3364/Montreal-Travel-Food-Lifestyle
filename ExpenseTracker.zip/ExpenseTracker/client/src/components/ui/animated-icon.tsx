import { LucideIcon } from "lucide-react";
import { motion, AnimationControls, useAnimation } from "framer-motion";
import { useEffect } from "react";
import { cn } from "@/lib/utils";

interface AnimatedIconProps {
  icon: LucideIcon;
  className?: string;
  size?: number;
  animationType?: "pulse" | "spin" | "bounce" | "shake" | "none";
  color?: string;
  autoAnimate?: boolean;
  animateOnHover?: boolean;
  strokeWidth?: number;
}

export function AnimatedIcon({
  icon: Icon,
  className,
  size = 24,
  animationType = "none",
  color,
  autoAnimate = false,
  animateOnHover = false,
  strokeWidth = 2,
}: AnimatedIconProps) {
  const controls: AnimationControls = useAnimation();

  // Define animation variants
  const getAnimationVariant = () => {
    switch (animationType) {
      case "pulse":
        return {
          animate: {
            scale: [1, 1.2, 1],
            transition: {
              duration: 1.5,
              repeat: autoAnimate ? Infinity : 0,
              repeatType: "loop" as const,
            },
          },
          hover: {
            scale: [1, 1.2, 1],
            transition: {
              duration: 0.5,
            },
          },
        };
      case "spin":
        return {
          animate: {
            rotate: 360,
            transition: {
              duration: 2,
              repeat: autoAnimate ? Infinity : 0,
              ease: "linear",
            },
          },
          hover: {
            rotate: 180,
            transition: {
              duration: 0.5,
            },
          },
        };
      case "bounce":
        return {
          animate: {
            y: ["0%", "-20%", "0%"],
            transition: {
              duration: 1,
              repeat: autoAnimate ? Infinity : 0,
              repeatType: "loop" as const,
            },
          },
          hover: {
            y: ["0%", "-20%", "0%"],
            transition: {
              duration: 0.5,
            },
          },
        };
      case "shake":
        return {
          animate: {
            x: [0, -5, 5, -5, 5, 0],
            transition: {
              duration: 0.5,
              repeat: autoAnimate ? Infinity : 0,
              repeatType: "loop" as const,
              repeatDelay: 1,
            },
          },
          hover: {
            x: [0, -5, 5, -5, 5, 0],
            transition: {
              duration: 0.4,
            },
          },
        };
      default:
        return {
          animate: {},
          hover: {
            scale: 1.1,
            transition: {
              duration: 0.2,
            },
          },
        };
    }
  };

  const animations = getAnimationVariant();

  useEffect(() => {
    if (autoAnimate && animationType !== "none") {
      controls.start(animations.animate);
    }
  }, [autoAnimate, animationType]);

  const handleHoverStart = () => {
    if (animateOnHover && animationType !== "none") {
      controls.start(animations.hover);
    }
  };

  return (
    <motion.div
      className={cn("inline-flex", className)}
      animate={controls}
      onHoverStart={handleHoverStart}
      whileHover={animateOnHover && animationType === "none" ? { scale: 1.1 } : {}}
      whileTap={animateOnHover ? { scale: 0.95 } : {}}
    >
      <Icon
        size={size}
        color={color}
        strokeWidth={strokeWidth}
      />
    </motion.div>
  );
}