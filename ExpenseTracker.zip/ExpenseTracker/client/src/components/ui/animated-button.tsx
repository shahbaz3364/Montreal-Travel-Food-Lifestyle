import { ButtonProps, Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { forwardRef } from "react";

interface AnimatedButtonProps extends ButtonProps {
  animationType?: "bounce" | "tap" | "pulse" | "none";
}

const AnimatedButton = forwardRef<HTMLButtonElement, AnimatedButtonProps>(
  ({ animationType = "tap", className, children, ...props }, ref) => {
    // Define animation variants
    const getAnimationProps = () => {
      switch (animationType) {
        case "bounce":
          return {
            whileTap: { scale: 0.95 },
            whileHover: { scale: 1.02 },
          };
        case "pulse":
          return {
            whileHover: { scale: 1.02 },
            whileTap: { scale: 0.95 },
          };
        case "tap":
          return {
            whileTap: { scale: 0.95 },
          };
        default:
          return {};
      }
    };

    const animationProps = getAnimationProps();

    return (
      <div className="inline-block">
        <motion.div
          className="inline-block"
          {...animationProps}
        >
          <Button 
            ref={ref}
            className={className}
            {...props}
          >
            {children}
          </Button>
        </motion.div>
      </div>
    );
  }
);

AnimatedButton.displayName = "AnimatedButton";

export { AnimatedButton };