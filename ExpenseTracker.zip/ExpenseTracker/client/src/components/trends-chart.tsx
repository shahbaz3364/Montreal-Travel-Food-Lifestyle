import { useEffect, useRef } from "react";
import { Chart, LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend, LineController } from "chart.js";
import { MonthlyExpenseSummary } from "@shared/schema";

// Register Chart.js components
Chart.register(LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend, LineController);

interface TrendsChartProps {
  data?: MonthlyExpenseSummary;
  period: string;
}

export default function TrendsChart({ data, period }: TrendsChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  // Generate mock data for demonstration purposes
  // In a real app, this would use actual API data
  const generateMockData = () => {
    const days = Array.from({ length: 30 }, (_, i) => i + 1);
    const values = days.map(() => Math.floor(Math.random() * 100) + 20);
    
    return { days, values };
  };
  
  // Initialize or update chart
  useEffect(() => {
    if (!chartRef.current) return;
    
    // Prepare chart data
    const { days, values } = generateMockData();
    
    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Create new chart
    const ctx = chartRef.current.getContext('2d');
    if (ctx) {
      chartInstance.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: days,
          datasets: [{
            label: 'Daily Spending',
            data: values,
            borderColor: '#00E5FF',
            backgroundColor: 'rgba(0, 229, 255, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointRadius: 3,
            pointBackgroundColor: '#00E5FF',
            pointBorderColor: '#121212',
            pointHoverRadius: 5,
            pointHoverBackgroundColor: '#FFFFFF',
            pointHoverBorderColor: '#00E5FF',
            pointHoverBorderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: {
                display: false,
                color: 'rgba(255, 255, 255, 0.1)'
              },
              ticks: {
                color: 'rgba(255, 255, 255, 0.5)',
                font: {
                  size: 10
                },
                maxRotation: 0,
                autoSkip: true,
                maxTicksLimit: 7
              }
            },
            y: {
              grid: {
                color: 'rgba(255, 255, 255, 0.1)'
              },
              ticks: {
                color: 'rgba(255, 255, 255, 0.5)',
                font: {
                  size: 10
                },
                callback: (value) => `$${value}`
              },
              beginAtZero: true
            }
          },
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              backgroundColor: 'rgba(0, 0, 0, 0.8)',
              titleColor: 'white',
              bodyColor: 'white',
              borderColor: 'rgba(255, 255, 255, 0.1)',
              borderWidth: 1,
              padding: 10,
              displayColors: false,
              callbacks: {
                label: (context) => {
                  const value = context.raw as number;
                  return `$${value.toFixed(2)}`;
                }
              }
            }
          }
        }
      });
    }
    
    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, period]);
  
  return (
    <div className="h-64 w-full">
      <canvas ref={chartRef} />
    </div>
  );
}
