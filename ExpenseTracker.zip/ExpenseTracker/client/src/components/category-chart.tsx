import { useEffect, useRef } from "react";
import { Chart, ArcElement, Tooltip, Legend, DoughnutController } from "chart.js";
import { type ExpenseSummary, EXPENSE_CATEGORIES } from "@shared/schema";

// Register Chart.js components
Chart.register(ArcElement, Tooltip, Legend, DoughnutController);

interface CategoryChartProps {
  categories: ExpenseSummary[];
}

export default function CategoryChart({ categories }: CategoryChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  // Define chart colors for each category
  const getCategoryColor = (categoryId: string): string => {
    const category = EXPENSE_CATEGORIES.find(c => c.id === categoryId);
    switch (category?.color) {
      case "neon-blue": return "#00E5FF";
      case "neon-purple": return "#9D4EDD";
      case "neon-green": return "#39FF14";
      case "neon-pink": return "#FF00E5";
      case "yellow-400": return "#FFD600";
      case "red-400": return "#FF4444";
      case "blue-400": return "#4DACFF";
      default: return "#AAAAAA";
    }
  };

  // Initialize or update chart
  useEffect(() => {
    if (!chartRef.current || categories.length === 0) return;

    // Prepare chart data
    const labels = categories.map(cat => {
      const categoryObj = EXPENSE_CATEGORIES.find(c => c.id === cat.category);
      return categoryObj?.name || cat.category;
    });
    
    const data = categories.map(cat => cat.total);
    const backgroundColors = categories.map(cat => getCategoryColor(cat.category));
    
    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Create new chart
    const ctx = chartRef.current.getContext('2d');
    if (ctx) {
      chartInstance.current = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels,
          datasets: [{
            data,
            backgroundColor: backgroundColors,
            borderColor: 'rgba(30, 30, 30, 1)',
            borderWidth: 2,
            hoverOffset: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              backgroundColor: 'rgba(0, 0, 0, 0.8)',
              titleColor: 'white',
              bodyColor: 'white',
              borderColor: 'rgba(255, 255, 255, 0.1)',
              borderWidth: 1,
              padding: 10,
              displayColors: true,
              callbacks: {
                label: (context) => {
                  const value = context.raw as number;
                  return `$${value.toFixed(2)} (${categories[context.dataIndex]?.percentage}%)`;
                }
              }
            }
          },
          cutout: '70%'
        }
      });
    }
    
    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [categories]);
  
  return (
    <div className="relative h-[200px]">
      <canvas ref={chartRef} height="200"></canvas>
      
      {categories.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-gray-400 text-sm">No expense data available</p>
        </div>
      )}
      
      {categories.length > 0 && (
        <div className="mt-4 flex justify-between text-sm">
          <div className="flex flex-col space-y-2 max-w-[70%]">
            {categories.slice(0, 3).map((category, index) => (
              <div key={index} className="flex items-center">
                <div 
                  className="w-3 h-3 rounded-full mr-2"
                  style={{ 
                    backgroundColor: getCategoryColor(category.category),
                    boxShadow: `0 0 5px ${getCategoryColor(category.category)}` 
                  }}
                ></div>
                <span className="text-gray-300 truncate">
                  {EXPENSE_CATEGORIES.find(c => c.id === category.category)?.name || category.category}
                </span>
              </div>
            ))}
          </div>
          <div className="flex flex-col space-y-2 font-mono text-right">
            {categories.slice(0, 3).map((category, index) => (
              <div key={index} className="text-gray-300">
                ${category.total.toFixed(2)}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
