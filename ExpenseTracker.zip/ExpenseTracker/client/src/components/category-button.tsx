import { cn } from "@/lib/utils";

interface CategoryProps {
  id: string;
  name: string;
  icon: string;
  color: string;
}

interface CategoryButtonProps {
  category: CategoryProps;
  isSelected: boolean;
  onClick: () => void;
}

export default function CategoryButton({ category, isSelected, onClick }: CategoryButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "category-btn flex flex-col items-center p-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors",
        isSelected && "ring-2 ring-neon-blue"
      )}
    >
      <span className={`material-icons text-${category.color} mb-1`}>{category.icon}</span>
      <span className="text-xs text-gray-300">{category.name}</span>
    </button>
  );
}
