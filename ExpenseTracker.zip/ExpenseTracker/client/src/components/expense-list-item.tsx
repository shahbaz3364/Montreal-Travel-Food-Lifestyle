import { type Expense, EXPENSE_CATEGORIES } from "@shared/schema";

interface ExpenseListItemProps {
  expense: Expense;
}

export default function ExpenseListItem({ expense }: ExpenseListItemProps) {
  // Find category details
  const category = EXPENSE_CATEGORIES.find(c => c.id === expense.category);
  
  // Format date
  const formatDate = (date: Date | string) => {
    const expenseDate = new Date(date);
    const now = new Date();
    const today = new Date(now.setHours(0, 0, 0, 0));
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Format time
    const timeString = expenseDate.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
    
    // Check if today, yesterday, or another date
    if (expenseDate.toDateString() === today.toDateString()) {
      return `Today, ${timeString}`;
    } else if (expenseDate.toDateString() === yesterday.toDateString()) {
      return `Yesterday, ${timeString}`;
    } else {
      return expenseDate.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric'
      }) + `, ${timeString}`;
    }
  };
  
  return (
    <div className="border-b border-gray-700 py-3 flex justify-between items-center last:border-0">
      <div className="flex items-center">
        <div className={`w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center mr-3`}>
          <span className={`material-icons text-${category?.color || 'gray-400'}`}>
            {category?.icon || 'receipt'}
          </span>
        </div>
        <div>
          <p className="text-white">{expense.description || category?.name || 'Expense'}</p>
          <p className="text-xs text-gray-400">{formatDate(expense.date)}</p>
        </div>
      </div>
      <p className="font-mono text-white">-${Number(expense.amount).toFixed(2)}</p>
    </div>
  );
}
