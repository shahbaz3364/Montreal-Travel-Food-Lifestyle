import { Plus } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { AnimatedIcon } from "@/components/ui/animated-icon";
import { AnimatedButton } from "@/components/ui/animated-button";

export default function FloatingActionButton() {
  const [, navigate] = useLocation();
  
  return (
    <motion.div
      className="fixed bottom-20 right-4 z-10"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{
        type: "spring",
        stiffness: 260,
        damping: 20,
        delay: 0.5
      }}
      whileHover={{ 
        scale: 1.05,
        filter: "brightness(1.1)",
        transition: { duration: 0.2 }
      }}
      whileTap={{ scale: 0.95 }}
    >
      <AnimatedButton
        onClick={() => navigate("/add-expense")}
        className="w-16 h-16 rounded-full bg-neon-blue flex items-center justify-center hover:bg-opacity-90 p-0"
        style={{ 
          boxShadow: '0 0 15px rgba(0, 229, 255, 0.7)'
        }}
        animationType="none"
      >
        <AnimatedIcon 
          icon={Plus} 
          className="text-black" 
          size={28}
          animationType="none"
          strokeWidth={3} 
        />
      </AnimatedButton>
    </motion.div>
  );
}
