import { useLocation } from "wouter";
import { Home, BarChart2, Calendar, Settings } from "lucide-react";

export default function BottomNav() {
  const [location] = useLocation();
  
  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/reports", icon: BarChart2, label: "Reports" },
    { path: "/calendar", icon: Calendar, label: "Calendar" },
    { path: "/settings", icon: Settings, label: "Settings" }
  ];
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background-surface border-t border-gray-800 px-2 py-1 z-10">
      <div className="flex justify-around">
        {navItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <div 
              key={item.path} 
              onClick={() => window.location.href = item.path}
              className={`p-2 flex flex-col items-center ${isActive ? 'text-neon-blue' : 'text-gray-400 hover:text-gray-300'} cursor-pointer`}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </div>
          );
        })}
      </div>
    </nav>
  );
}
