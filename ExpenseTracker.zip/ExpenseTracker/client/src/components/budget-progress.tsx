import { cn } from "@/lib/utils";

interface BudgetProgressProps {
  percentage: number;
  className?: string;
}

export default function BudgetProgress({ percentage, className }: BudgetProgressProps) {
  // Determine color based on percentage
  const getColorClass = () => {
    if (percentage > 90) return "bg-status-error shadow-[0_0_8px_rgba(255,68,68,0.7)]";
    if (percentage > 75) return "bg-status-warning shadow-[0_0_8px_rgba(255,214,0,0.7)]";
    return "bg-neon-blue shadow-[0_0_8px_rgba(0,229,255,0.7)]";
  };
  
  return (
    <div className={cn("space-y-1", className)}>
      <div className="flex justify-between text-sm">
        <span className="text-gray-400">Budget progress</span>
        <span className="text-gray-300 font-mono">{percentage}%</span>
      </div>
      <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full ${getColorClass()}`} 
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
