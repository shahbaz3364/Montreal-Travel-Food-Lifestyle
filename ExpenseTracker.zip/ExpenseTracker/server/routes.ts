import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertExpenseSchema, insertBudgetSchema, ExpenseCategory, EXPENSE_CATEGORIES } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { setupAuth } from "./auth";
import { exportPdf, exportCsv } from "./export";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Middleware to ensure user is authenticated
  const ensureAuthenticated = (req: Request, res: Response, next: NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Not authenticated" });
  };
  
  // Get authenticated user ID
  const getUserId = (req: Request): number => {
    return req.user?.id || 0;
  };

  // API endpoint to get monthly summary
  app.get("/api/summary", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const date = new Date();
      
      if (req.query.month && req.query.year) {
        date.setMonth(Number(req.query.month) - 1);
        date.setFullYear(Number(req.query.year));
      }
      
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      
      const summary = await storage.getMonthlyExpenseSummary(userId, month, year);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch summary" });
    }
  });

  // API endpoint to list recent expenses
  app.get("/api/expenses/recent", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const limit = req.query.limit ? Number(req.query.limit) : 10;
      
      const expenses = await storage.listExpensesByUser(userId, limit);
      res.json(expenses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  // API endpoint to list expenses by month
  app.get("/api/expenses/monthly", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const date = new Date();
      
      if (req.query.month && req.query.year) {
        date.setMonth(Number(req.query.month) - 1);
        date.setFullYear(Number(req.query.year));
      }
      
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      
      const expenses = await storage.listExpensesByMonth(userId, month, year);
      res.json(expenses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch monthly expenses" });
    }
  });

  // API endpoint to create an expense
  app.post("/api/expenses", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const result = insertExpenseSchema.safeParse(req.body);
      
      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({ message: validationError.message });
      }
      
      const expense = await storage.createExpense(userId, result.data);
      res.status(201).json(expense);
    } catch (error) {
      res.status(500).json({ message: "Failed to create expense" });
    }
  });

  // API endpoint to delete an expense
  app.delete("/api/expenses/:id", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const expense = await storage.getExpense(id);
      
      if (!expense) {
        return res.status(404).json({ message: "Expense not found" });
      }
      
      if (expense.userId !== getUserId(req)) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      await storage.deleteExpense(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete expense" });
    }
  });

  // API endpoint to get or set budget
  app.route("/api/budget")
    .get(ensureAuthenticated, async (req: Request, res: Response) => {
      try {
        const userId = getUserId(req);
        const date = new Date();
        
        if (req.query.month && req.query.year) {
          date.setMonth(Number(req.query.month) - 1);
          date.setFullYear(Number(req.query.year));
        }
        
        const month = date.getMonth() + 1;
        const year = date.getFullYear();
        
        const budget = await storage.getBudget(userId, month, year);
        
        if (!budget) {
          return res.status(404).json({ message: "Budget not set for this month" });
        }
        
        res.json(budget);
      } catch (error) {
        res.status(500).json({ message: "Failed to fetch budget" });
      }
    })
    .post(ensureAuthenticated, async (req: Request, res: Response) => {
      try {
        const userId = getUserId(req);
        const result = insertBudgetSchema.safeParse(req.body);
        
        if (!result.success) {
          const validationError = fromZodError(result.error);
          return res.status(400).json({ message: validationError.message });
        }
        
        const budget = await storage.createOrUpdateBudget(userId, result.data);
        res.status(201).json(budget);
      } catch (error) {
        res.status(500).json({ message: "Failed to set budget" });
      }
    });

  // API endpoint to get category expenses for the month
  app.get("/api/categories", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const date = new Date();
      
      if (req.query.month && req.query.year) {
        date.setMonth(Number(req.query.month) - 1);
        date.setFullYear(Number(req.query.year));
      }
      
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      
      const categories = await storage.getCategoryExpenses(userId, month, year);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category expenses" });
    }
  });

  // API endpoint to get trends data
  app.get("/api/trends", ensureAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const category = req.query.category as string || 'all';
      const months = req.query.months ? Number(req.query.months) : 3;
      
      // If a specific category is requested
      if (category !== 'all') {
        // Type assertion to ExpenseCategory after validation
        const validCategories = EXPENSE_CATEGORIES.map(c => c.id);
        if (validCategories.includes(category as ExpenseCategory)) {
          const data = await storage.getMonthlyTotalsByCategory(userId, category as ExpenseCategory, months);
          return res.json(data);
        }
        return res.status(400).json({ message: "Invalid category" });
      }
      
      // Default response for all categories
      const date = new Date();
      const currentMonth = date.getMonth() + 1;
      const currentYear = date.getFullYear();
      
      const thisMonth = await storage.getMonthlyExpenseSummary(userId, currentMonth, currentYear);
      res.json({
        current: thisMonth,
        // In a real app, we'd fetch more data for a trends chart
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trends" });
    }
  });

  // API endpoint to export expenses as PDF
  app.get("/api/export/pdf", ensureAuthenticated, exportPdf);

  // API endpoint to export expenses as CSV/Excel
  app.get("/api/export/csv", ensureAuthenticated, exportCsv);

  const httpServer = createServer(app);
  return httpServer;
}
