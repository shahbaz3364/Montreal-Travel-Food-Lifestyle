import { Request, Response } from "express";
import PDFDocument from "pdfkit";
import { format } from "date-fns";
import ExcelJS from "exceljs";
import { storage } from "./storage";
import { EXPENSE_CATEGORIES } from "@shared/schema";

// Helper function to format currency
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

// Helper function to get category details by ID
const getCategoryById = (categoryId: string) => {
  const category = EXPENSE_CATEGORIES.find(cat => cat.id === categoryId);
  return category || { id: "unknown", name: "Unknown", icon: "help-circle", color: "#808080" };
};

// Filter expenses by date range
const filterExpensesByDateRange = async (userId: number, startDate: Date, endDate: Date) => {
  // Get all expenses for the user
  const allExpenses = await storage.listExpensesByUser(userId);
  
  // Filter expenses based on date range
  return allExpenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate >= startDate && expenseDate <= endDate;
  });
};

// Expense summary calculation
const generateExpenseSummary = (expenses: any[]) => {
  // Calculate total amount
  const totalAmount = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  // Group by category
  const categoryMap = new Map();
  expenses.forEach(expense => {
    const categoryId = expense.category;
    const currentAmount = categoryMap.get(categoryId) || 0;
    categoryMap.set(categoryId, currentAmount + expense.amount);
  });
  
  // Create summary by category
  const categorySummary = Array.from(categoryMap.entries()).map(([categoryId, amount]) => {
    const category = getCategoryById(categoryId as string);
    return {
      id: categoryId,
      name: category.name,
      amount: amount as number,
      percentage: totalAmount ? Math.round(((amount as number) / totalAmount) * 100) : 0
    };
  });
  
  // Sort by amount (descending)
  categorySummary.sort((a, b) => b.amount - a.amount);
  
  return {
    totalAmount,
    categorySummary
  };
};

// Export expenses as PDF
export async function exportPdf(req: Request, res: Response) {
  try {
    // Get user ID from authenticated session
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Get date range from query parameters
    const startDateStr = req.query.startDate as string || new Date().toISOString().slice(0, 10);
    const endDateStr = req.query.endDate as string || new Date().toISOString().slice(0, 10);
    
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    endDate.setHours(23, 59, 59, 999); // Include the entire day
    
    // Filter expenses by date range
    const expenses = await filterExpensesByDateRange(userId, startDate, endDate);
    
    // Generate summary statistics
    const summary = generateExpenseSummary(expenses);
    
    // Set headers for PDF download
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=expenses-${format(startDate, 'yyyy-MM-dd')}-to-${format(endDate, 'yyyy-MM-dd')}.pdf`);
    
    // Create PDF document
    const doc = new PDFDocument({ margin: 50 });
    doc.pipe(res);
    
    // Add document title
    doc.font('Helvetica-Bold').fontSize(20).text('Expense Report', { align: 'center' });
    doc.moveDown();
    
    // Add date range
    doc.font('Helvetica').fontSize(12)
      .text(`Date Range: ${format(startDate, 'MMMM d, yyyy')} to ${format(endDate, 'MMMM d, yyyy')}`, { align: 'center' });
    doc.moveDown(2);
    
    // Add summary section
    doc.font('Helvetica-Bold').fontSize(16).text('Summary', { underline: true });
    doc.moveDown();
    doc.font('Helvetica').fontSize(12)
      .text(`Total Expenses: ${formatCurrency(summary.totalAmount)}`);
    doc.moveDown();
    
    // Add category breakdown
    doc.font('Helvetica-Bold').fontSize(14).text('Expenses by Category');
    doc.moveDown();
    
    summary.categorySummary.forEach(categoryStat => {
      doc.font('Helvetica-Bold').fontSize(12).text(categoryStat.name);
      doc.font('Helvetica').fontSize(12)
        .text(`${formatCurrency(categoryStat.amount)} (${categoryStat.percentage}%)`);
      doc.moveDown(0.5);
    });
    doc.moveDown();
    
    // Add expense details table
    doc.font('Helvetica-Bold').fontSize(14).text('Expense Details');
    doc.moveDown();
    
    // Table header
    const tableTop = doc.y;
    const tableHeaders = ['Date', 'Category', 'Description', 'Amount'];
    const columnWidth = (doc.page.width - 100) / tableHeaders.length;
    
    // Draw header
    doc.font('Helvetica-Bold').fontSize(12);
    tableHeaders.forEach((header, i) => {
      doc.text(header, 50 + (i * columnWidth), tableTop, { width: columnWidth, align: 'left' });
    });
    
    // Draw line under headers
    doc.moveTo(50, tableTop + 20).lineTo(doc.page.width - 50, tableTop + 20).stroke();
    
    // Table rows
    let rowTop = tableTop + 30;
    doc.font('Helvetica').fontSize(10);
    
    expenses.forEach((expense, index) => {
      // Add a new page if near the bottom
      if (rowTop > doc.page.height - 100) {
        doc.addPage();
        rowTop = 50;
      }
      
      const category = getCategoryById(expense.category);
      
      // Format date
      const expenseDate = new Date(expense.date);
      const formattedDate = format(expenseDate, 'MMM d, yyyy');
      
      // Draw row
      doc.text(formattedDate, 50, rowTop, { width: columnWidth, align: 'left' });
      doc.text(category.name, 50 + columnWidth, rowTop, { width: columnWidth, align: 'left' });
      doc.text(expense.description, 50 + (2 * columnWidth), rowTop, { width: columnWidth, align: 'left' });
      doc.text(formatCurrency(expense.amount), 50 + (3 * columnWidth), rowTop, { width: columnWidth, align: 'left' });
      
      rowTop += 20;
      
      // Draw line under row if not the last row
      if (index < expenses.length - 1) {
        doc.moveTo(50, rowTop - 10).lineTo(doc.page.width - 50, rowTop - 10).stroke('#eeeeee');
      }
    });
    
    // Add a border around the table
    doc.rect(50, tableTop, doc.page.width - 100, rowTop - tableTop).stroke();
    
    // Finalize and send the PDF
    doc.end();
    
  } catch (error) {
    console.error("PDF export error:", error);
    res.status(500).json({ message: "Failed to generate PDF export" });
  }
}

// Export expenses as CSV
export async function exportCsv(req: Request, res: Response) {
  try {
    // Get user ID from authenticated session
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Get date range from query parameters
    const startDateStr = req.query.startDate as string || new Date().toISOString().slice(0, 10);
    const endDateStr = req.query.endDate as string || new Date().toISOString().slice(0, 10);
    
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    endDate.setHours(23, 59, 59, 999); // Include the entire day
    
    // Filter expenses by date range
    const expenses = await filterExpensesByDateRange(userId, startDate, endDate);
    
    // Generate summary statistics
    const summary = generateExpenseSummary(expenses);
    
    // Create a new Excel workbook
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Expense Tracker';
    workbook.created = new Date();
    
    // Add a summary worksheet
    const summarySheet = workbook.addWorksheet('Summary');
    
    // Add title and date range
    summarySheet.addRow(['Expense Report']);
    summarySheet.addRow([`Date Range: ${format(startDate, 'MMMM d, yyyy')} to ${format(endDate, 'MMMM d, yyyy')}`]);
    summarySheet.addRow([]);
    
    // Add total expenses
    summarySheet.addRow(['Total Expenses', formatCurrency(summary.totalAmount)]);
    summarySheet.addRow([]);
    
    // Add category breakdown
    summarySheet.addRow(['Category', 'Amount', 'Percentage']);
    summary.categorySummary.forEach(categoryStat => {
      summarySheet.addRow([
        categoryStat.name,
        formatCurrency(categoryStat.amount),
        `${categoryStat.percentage}%`
      ]);
    });
    
    // Style the summary sheet
    summarySheet.getColumn(1).width = 25;
    summarySheet.getColumn(2).width = 15;
    summarySheet.getColumn(3).width = 15;
    
    summarySheet.getCell('A1').font = { bold: true, size: 16 };
    summarySheet.getRow(6).font = { bold: true };
    
    // Add an expenses worksheet
    const expensesSheet = workbook.addWorksheet('Expenses');
    
    // Add headers
    expensesSheet.addRow(['Date', 'Category', 'Description', 'Amount']);
    
    // Add expense data
    expenses.forEach(expense => {
      const category = getCategoryById(expense.category);
      const expenseDate = new Date(expense.date);
      
      expensesSheet.addRow([
        format(expenseDate, 'MMM d, yyyy'),
        category.name,
        expense.description,
        expense.amount
      ]);
    });
    
    // Style the expenses sheet
    expensesSheet.getColumn(1).width = 15;
    expensesSheet.getColumn(2).width = 20;
    expensesSheet.getColumn(3).width = 40;
    expensesSheet.getColumn(4).width = 15;
    
    expensesSheet.getRow(1).font = { bold: true };
    
    // Format the amount column as currency
    expensesSheet.getColumn(4).numFmt = '$#,##0.00';
    
    // Set headers for Excel download
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=expenses-${format(startDate, 'yyyy-MM-dd')}-to-${format(endDate, 'yyyy-MM-dd')}.xlsx`);
    
    // Write to response
    await workbook.xlsx.write(res);
    res.end();
    
  } catch (error) {
    console.error("CSV export error:", error);
    res.status(500).json({ message: "Failed to generate CSV export" });
  }
}