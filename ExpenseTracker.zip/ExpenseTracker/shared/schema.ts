import { pgTable, text, serial, integer, decimal, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Categories with proper icon mapping
export const EXPENSE_CATEGORIES = [
  { id: "food", name: "Food", icon: "restaurant", color: "neon-blue" },
  { id: "transport", name: "Transport", icon: "directions_car", color: "neon-purple" },
  { id: "shopping", name: "Shopping", icon: "shopping_bag", color: "neon-green" },
  { id: "utilities", name: "Utilities", icon: "bolt", color: "neon-pink" },
  { id: "entertainment", name: "Fun", icon: "movie", color: "yellow-400" },
  { id: "health", name: "Health", icon: "favorite", color: "red-400" },
  { id: "education", name: "Education", icon: "school", color: "blue-400" },
  { id: "other", name: "Other", icon: "more_horiz", color: "gray-400" },
] as const;

export type ExpenseCategory = typeof EXPENSE_CATEGORIES[number]["id"];

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Expense schema
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  description: text("description"),
  date: timestamp("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertExpenseSchema = createInsertSchema(expenses)
  .omit({ id: true, createdAt: true, userId: true })
  .extend({
    amount: z.coerce.number().positive("Amount must be positive"),
    category: z.enum([
      "food",
      "transport",
      "shopping",
      "utilities",
      "entertainment",
      "health",
      "education",
      "other"
    ]),
    date: z.coerce.date(),
  });

// Budget schema
export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
});

export const insertBudgetSchema = createInsertSchema(budgets)
  .omit({ id: true, userId: true })
  .extend({
    amount: z.coerce.number().positive("Budget amount must be positive"),
    month: z.number().min(1).max(12),
    year: z.number().min(2000).max(2100),
  });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Budget = typeof budgets.$inferSelect;
export type InsertBudget = z.infer<typeof insertBudgetSchema>;

// For frontend use
export type ExpenseSummary = {
  category: ExpenseCategory;
  total: number;
  percentage: number;
};

export type MonthlyExpenseSummary = {
  totalSpent: number;
  budget: number;
  budgetRemaining: number;
  budgetPercentage: number;
  categories: ExpenseSummary[];
};
